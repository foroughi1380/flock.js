
class FlockMember {
    constructor(opts = {}) {
        this.channelName = opts.channelName || 'shepherd';
        this.debug = opts.debug || false;

        // internal election instance
        this.flock = new Flock({ channelName: this.channelName, debug: this.debug });

        // member id
        this.id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}`;

        // listeners
        this.messageListeners = new Set();
        this.requestCallbacks = new Map();
        this.requestIdCounter = 0;

        // hook into leader messages
        this.flock.onLeaderMessage(msg => this._handleMessage(msg));

        // auto start election
        this.flock.start();
    }

    _log(...args) { if (this.debug) console.debug('[FlockMember]', ...args); }

    _handleMessage(msg) {
        const { type, payload, requestId, target } = msg;
        if (target && target !== this.id) return;

        if (type === 'leader-response' && requestId !== undefined) {
            const cb = this.requestCallbacks.get(requestId);
            if (cb) { cb(payload); this.requestCallbacks.delete(requestId); }
        } else {
            this.messageListeners.forEach(cb => cb(payload));
        }
    }

    send(data, expectResponse = false) {
        if (expectResponse) {
            const requestId = this.requestIdCounter++;
            return new Promise(resolve => {
                this.requestCallbacks.set(requestId, resolve);
                this.flock.sendToLeader({ ...data, sourceId: this.id }, true);
            });
        } else {
            this.flock.sendToLeader({ ...data, sourceId: this.id }, false);
        }
    }

    onMessage(callback) {
        this.messageListeners.add(callback);
        return () => this.messageListeners.delete(callback);
    }

    isLeader() { return this.flock.isLeader(); }

    broadcast(data) {
        if (this.isLeader()) {
            this.flock.broadcast({ ...data, sourceId: this.id });
        } else {
            this._log('Cannot broadcast: not leader');
        }
    }

    sendToMember(memberId, data) {
        if (this.isLeader()) {
            this.flock.sendToMember(memberId, { ...data, sourceId: this.id });
        } else {
            this._log('Cannot send to member: not leader');
        }
    }

    getMembers() {
        if (this.isLeader()) return this.flock.getMembers();
        this._log('Cannot get members: not leader');
        return [];
    }

    onLeadershipChange(callback) {
        this.flock.onLeadershipChange(callback);
    }
}

// Export for module environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { FlockMember };
} else {
    window.FlockMember = FlockMember;
}
