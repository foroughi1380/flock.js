
function createLeaderElection(opts = {}) {
    const channelName = opts.channelName || 'leader-election';
    const heartbeatInterval = opts.heartbeatInterval || 2000;
    const heartbeatTTL = opts.heartbeatTTL || 5000;
    const claimDelayBase = opts.claimDelayBase || 100;
    const id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}`;

    let bc = null;
    let isRunning = false;
    let leader = null;
    let isLeader = false;
    let heartbeatTimer = null;
    let checkTimer = null;
    const listeners = new Set();

    const LS_KEY = `leader:${channelName}`;
    const LS_BUMP = `bump:${channelName}`;

    function log(...args) { if (opts.debug) console.debug('[LeaderElector]', ...args); }

    function postMessage(msg) {
        if (bc) {
            try { bc.postMessage(msg); } catch(e){ log('bc postMessage failed', e); }
        } else {
            try { localStorage.setItem(LS_BUMP, JSON.stringify({ id, msg, ts: Date.now() })); }
            catch(e){ log('localStorage postMessage failed', e); }
        }
    }

    function writeLeaderToLocalStorage(leaderObj) {
        try {
            localStorage.setItem(LS_KEY, JSON.stringify(leaderObj));
            localStorage.setItem(LS_BUMP, JSON.stringify({ id, bump: Date.now() }));
        } catch(e){ log('writeLeaderToLocalStorage failed', e); }
    }

    function readLeaderFromLocalStorage() {
        try {
            const s = localStorage.getItem(LS_KEY);
            if (!s) return null;
            return JSON.parse(s);
        } catch { return null; }
    }

    function handleIncoming(msg) {
        if (!msg) return;
        const { type, payload } = msg;
        if (type === 'heartbeat') {
            const { id: lid, ts } = payload;
            if (!leader || leader.ts < ts || (leader.ts === ts && leader.id < lid)) {
                leader = { id: lid, ts };
                notifyIfChanged();
            }
        } else if (type === 'claim') {
            const { id: cid, ts } = payload;
            if (!leader || leader.ts < ts || (leader.ts === ts && leader.id < cid)) {
                leader = { id: cid, ts };
                notifyIfChanged();
            }
        } else if (type === 'resign') {
            const { id: rid } = payload;
            if (leader && leader.id === rid) {
                leader = null;
                notifyIfChanged();
            }
        } else if (type === 'whois') {
            if (isLeader) postMessage({ type:'heartbeat', payload:{ id, ts: Date.now() } });
        }
    }

    function onBroadcastMessage(e) { handleIncoming(e?.data); }

    function onStorageEvent(e) {
        if (!e.key) return;
        if (e.key === LS_BUMP) {
            try {
                const bump = JSON.parse(e.newValue);
                if (bump?.msg) handleIncoming(bump.msg);
                else {
                    const l = readLeaderFromLocalStorage();
                    if (l) { leader = l; notifyIfChanged(); }
                }
            } catch {}
        } else if (e.key === LS_KEY) {
            const l = readLeaderFromLocalStorage();
            leader = l;
            notifyIfChanged();
        }
    }

    function notifyIfChanged() {
        const prev = isLeader;
        isLeader = leader && leader.id === id;
        if (prev !== isLeader) listeners.forEach(cb => { try { cb(isLeader); } catch{} });
    }

    function startHeartbeat() {
        stopHeartbeat();
        heartbeatTimer = setInterval(() => {
            if (isLeader) {
                const msg = { type:'heartbeat', payload:{ id, ts: Date.now() } };
                postMessage(msg);
                if (!bc) writeLeaderToLocalStorage({ id, ts: Date.now() });
            }
        }, heartbeatInterval);
    }

    function stopHeartbeat() { if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer=null; } }

    function periodicCheck() {
        checkTimer = setInterval(() => {
            const now = Date.now();
            if (leader && (now - leader.ts) > heartbeatTTL) {
                leader = null;
                notifyIfChanged();
                attemptClaimWithJitter();
            }
        }, Math.max(500, Math.floor(heartbeatInterval/2)));
    }

    function attemptClaimWithJitter() {
        const delay = claimDelayBase + Math.floor(Math.random()*claimDelayBase);
        setTimeout(requestLeadership, delay);
    }

    function requestLeadership() {
        const ts = Date.now();
        postMessage({ type:'claim', payload:{ id, ts } });
        if (!leader || leader.ts < ts || (leader.ts === ts && leader.id < id)) {
            leader = { id, ts };
            notifyIfChanged();
        }
    }

    function resignLeadership() {
        if (isLeader) {
            postMessage({ type:'resign', payload:{ id } });
            if (!bc) localStorage.removeItem(LS_KEY);
            leader = null;
            notifyIfChanged();
        }
    }

    function start() {
        if (isRunning) return;
        isRunning = true;
        if ('BroadcastChannel' in self) {
            try { bc = new BroadcastChannel(channelName); bc.addEventListener('message', onBroadcastMessage); } catch{ bc=null; }
        }
        if (!bc) window.addEventListener('storage', onStorageEvent);
        postMessage({ type:'whois' });
        setTimeout(() => {
            const l = leader || readLeaderFromLocalStorage();
            if (l) leader = l;
            notifyIfChanged();
            if (!leader) attemptClaimWithJitter();
            startHeartbeat();
            periodicCheck();
        }, 150);
    }

    function stop() {
        if (!isRunning) return;
        isRunning = false;
        stopHeartbeat();
        if (checkTimer) { clearInterval(checkTimer); checkTimer=null; }
        resignLeadership();
        if (bc) { bc.removeEventListener('message', onBroadcastMessage); bc.close(); bc=null; }
        else window.removeEventListener('storage', onStorageEvent);
        listeners.clear();
    }

    function onLeadershipChange(cb) { listeners.add(cb); return ()=>listeners.delete(cb); }
    function isLeaderNow() { return !!isLeader; }

    return { start, stop, isLeader: isLeaderNow, requestLeadership, resignLeadership, onLeadershipChange };
}


class Flock {
    constructor(opts = {}) {
        this.elector = createLeaderElection(opts);
        this.members = new Map(); // memberId => lastSeen
    }

    start() {
        this.elector.start();
    }

    stop() {
        this.elector.stop();
    }

    isLeader() {
        return this.elector.isLeader();
    }

    sendToLeader(data, expectResponse = false) {
        return this.elector.sendToLeader(data, expectResponse);
    }

    sendToMember(memberId, data) {
        this.elector.sendToMember(memberId, data);
    }

    broadcast(data) {
        this.elector.broadcast(data);
    }

    getMembers() {
        return this.elector.getMembers();
    }

    onLeaderMessage(callback) {
        return this.elector.onLeaderMessage(callback);
    }
}

// Export for module environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Flock };
} else {
    window.Flock = Flock;
}